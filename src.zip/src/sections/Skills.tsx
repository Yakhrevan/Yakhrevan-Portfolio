import { motion } from 'framer-motion';
import { Code, Cpu, Activity, PenTool, Globe, Wrench, type LucideIcon } from 'lucide-react';
import { SKILLS_DATA } from '../data/portfolioData';

const ICONS: Record<string, LucideIcon> = { Code, Cpu, Activity, PenTool, Globe, Wrench };

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] },
  },
};

export function Skills() {
  return (
    <section id="skills" className="py-24 bg-brand-bg relative overflow-hidden">
      {/* Background ambient */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-brand-sky/8 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-blue/5 rounded-full blur-3xl pointer-events-none" />

      <div className="container-x relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl"
        >
          <span className="eyebrow">Skills & Technologies</span>
          <h2 className="h2 mt-4">
            Tools that Power <span className="text-brand-blue">My Ideas</span>
          </h2>
          <p className="mt-3 text-brand-slate">
            A combination of software, hardware and creativity.
          </p>
        </motion.div>

        {/* Skills Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
          className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          {SKILLS_DATA.map((category) => {
            const Icon = ICONS[category.iconName] ?? Code;
            return (
              <motion.div
                key={category.title}
                variants={cardVariants}
                className="card p-6 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300 group"
              >
                {/* Category header */}
                <div className="flex items-center gap-3 mb-5">
                  <div className="p-2.5 rounded-xl bg-gradient-to-br from-brand-blue to-brand-sky text-white shadow-glow-blue/20">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-extrabold text-brand-navy">{category.title}</h3>
                </div>

                {/* Skills as tag pills — no percentage bars */}
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill) => (
                    <div
                      key={skill.name}
                      className="group/skill relative px-3 py-1.5 rounded-lg bg-brand-bg border border-slate-100 hover:border-brand-sky/40 hover:bg-brand-sky-light transition-all duration-200 cursor-default"
                    >
                      <span className="text-sm font-semibold text-brand-navy group-hover/skill:text-brand-blue transition-colors">
                        {skill.name}
                      </span>
                      {/* Tooltip with tagline */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-lg bg-brand-navy text-white text-[11px] font-medium whitespace-nowrap opacity-0 group-hover/skill:opacity-100 transition-opacity pointer-events-none shadow-lg z-10">
                        {skill.tagline}
                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-brand-navy" />
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
