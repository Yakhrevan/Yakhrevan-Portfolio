import { motion } from 'framer-motion';
import { EXPERIENCE_DATA } from '../data/portfolioData';
import { Robot, SpeechNote } from '../components/Robot';

export function Experience() {
  return (
    <section id="experience" className="py-24 bg-brand-bg">
      <div className="container-x grid lg:grid-cols-[1fr_auto] gap-10">
        <div>
          <span className="eyebrow">My Journey</span>
          <h2 className="h2 mt-4">Learning · Building · <span className="text-brand-blue">Growing</span></h2>
          <div className="mt-12 relative border-l-2 border-blue-200 ml-3 space-y-10">
            {EXPERIENCE_DATA.map((e, i) => (
              <motion.div key={e.id} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="pl-8 relative">
                <span className="absolute -left-[9px] top-1.5 w-4 h-4 rounded-full bg-brand-blue ring-4 ring-white" />
                <p className="text-sm font-extrabold text-brand-navy/60">{e.period}</p>
                <h3 className="text-lg font-extrabold mt-0.5">{e.role}</h3>
                <p className="text-brand-blue font-semibold text-sm">{e.company}</p>
                <p className="mt-1.5 text-sm text-brand-slate max-w-xl">{e.description}</p>
                <div className="mt-3 flex flex-wrap gap-2">{e.technologies.map((t) => <span key={t} className="px-2 py-0.5 rounded bg-white border border-slate-200 text-[11px] font-mono text-brand-slate">{t}</span>)}</div>
              </motion.div>
            ))}
          </div>
        </div>
        <div className="hidden lg:flex flex-col items-center justify-center relative">
          <SpeechNote className="mb-4 rotate-6">Every step<br />counts!</SpeechNote>
          <Robot pose="back" className="w-72 h-[30rem]" />
        </div>
      </div>
    </section>
  );
}
