import { motion } from 'framer-motion';
import { Mail, Linkedin, Github, ArrowRight } from 'lucide-react';
import { PERSONAL_INFO as P } from '../data/portfolioData';
import { Robot3D } from '../components/Robot3D';

const CONTACT_LINKS = [
  {
    icon: Mail,
    label: 'Email',
    value: P.socials.email,
    href: `mailto:${P.socials.email}`,
  },
  {
    icon: Linkedin,
    label: 'LinkedIn',
    value: 'linkedin.com/in/yakhrevan',
    href: P.socials.linkedin,
  },
  {
    icon: Github,
    label: 'GitHub',
    value: 'github.com/Yakhrevan',
    href: P.socials.github,
  },
];

export function Contact() {
  return (
    <section id="contact" className="py-24 bg-brand-bg relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-brand-sky/8 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-brand-blue/6 rounded-full blur-3xl pointer-events-none" />

      <div className="container-x relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Content */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6 }}
          >
            <span className="eyebrow">Let's Connect</span>
            <h2 className="h2 mt-4">
              Have an idea?
              <br />
              Let's build it{' '}
              <span className="text-brand-blue">together.</span>
            </h2>
            <p className="mt-4 text-brand-slate max-w-md leading-relaxed">
              I'm always open to discussing robotics projects, engineering opportunities, collaboration, or interesting technical ideas. Let's create something meaningful.
            </p>

            {/* Contact links */}
            <div className="mt-8 space-y-3">
              {CONTACT_LINKS.map(({ icon: Icon, label, value, href }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  className="card p-4 flex gap-4 items-center hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200 group"
                >
                  <div className="p-2.5 rounded-xl bg-brand-sky-light text-brand-blue group-hover:bg-brand-blue group-hover:text-white transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-brand-navy">{label}</p>
                    <p className="text-xs text-brand-slate truncate">{value}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-brand-blue group-hover:translate-x-1 transition-all" />
                </a>
              ))}
            </div>

            {/* Primary CTA */}
            <a
              href={`mailto:${P.socials.email}`}
              className="btn-primary mt-8 inline-flex"
            >
              Let's Connect <ArrowRight className="w-4 h-4" />
            </a>
          </motion.div>

          {/* Right: Robot image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="flex justify-center"
          >
            <div className="relative w-full h-[320px] sm:h-[400px]">
              {/* Background glow */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-brand-sky/15 via-brand-blue/10 to-transparent blur-3xl pointer-events-none" />
              <Robot3D
                clip="Big_Wave_Hello"
                className="w-full h-full"
                cam={[0, 1.0, 3.5]}
                fov={34}
              />
              {/* Speech bubble */}
              <div className="absolute top-4 right-0 font-hand text-lg text-brand-blue bg-white/95 backdrop-blur-sm px-4 py-2 rounded-2xl shadow-card border border-brand-sky/20 select-none z-20">
                Let's Create
                <br />
                Build · Innovate! ⚡
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
