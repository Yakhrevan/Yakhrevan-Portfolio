import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Github, Linkedin, Mail } from 'lucide-react';
import { Robot3D } from '../components/Robot3D';
import { PERSONAL_INFO as P } from '../data/portfolioData';
import type { ClipName } from '../components/RobotModel';

export function Hero() {
  const [robotClip, setRobotClip] = useState<ClipName>('Idle_15');

  return (
    <section
      id="home"
      className="bg-hero relative overflow-hidden pt-28 pb-16 lg:pt-32 min-h-screen flex items-center"
    >
      {/* Background elements */}
      <div className="absolute inset-0 grid-dots opacity-30 [mask-image:radial-gradient(60%_60%_at_70%_40%,#000,transparent)] pointer-events-none" />
      <div className="absolute top-1/4 left-10 w-72 h-72 bg-brand-sky/12 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-brand-blue/8 rounded-full blur-3xl pointer-events-none" />

      <div className="container-x relative grid lg:grid-cols-12 gap-10 items-center">
        {/* Left Column: Text + CTA */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="lg:col-span-6 space-y-6"
        >
          {/* Profile badge */}
          <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-white/90 backdrop-blur-md border border-slate-200/80 shadow-sm">
            <div className="relative w-7 h-7 rounded-full overflow-hidden ring-2 ring-brand-blue/30 shrink-0">
              <img src="/profile.jpg" alt={P.name} className="w-full h-full object-cover" />
            </div>
            <span className="text-xs font-bold text-brand-navy tracking-wide">
              {P.name}{' '}
              <span className="text-slate-400 font-normal">| Mechatronics & Robotics</span>
            </span>
            <span className="flex h-2 w-2 relative" aria-label="Available">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-extrabold leading-[1.05] tracking-tight text-brand-navy">
            Hi, I'm
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-blue via-brand-sky to-brand-blue">
              {P.name}
            </span>
          </h1>

          {/* Tagline */}
          <p className="text-xl sm:text-2xl font-bold text-brand-navy/90 leading-snug">
            A small engineer
            <br />
            for a bigger tomorrow.
          </p>

          {/* Description */}
          <p className="max-w-md text-brand-slate leading-relaxed text-sm sm:text-base">
            I design, build and explore intelligent machines using robotics, embedded systems, autonomous systems, computer vision, AI and software.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-3 pt-2">
            <a
              href="#projects"
              className="btn-primary"
              onMouseEnter={() => setRobotClip('CrouchLookAroundBow')}
              onMouseLeave={() => setRobotClip('Idle_15')}
            >
              View My Work <ArrowRight className="w-4 h-4" />
            </a>
            <a
              href="#contact"
              className="btn-ghost"
              onMouseEnter={() => setRobotClip('Big_Wave_Hello')}
              onMouseLeave={() => setRobotClip('Idle_15')}
            >
              Let's Connect
            </a>
          </div>

          {/* Social icons */}
          <div className="flex items-center gap-3 pt-2">
            {[
              [Github, P.socials.github, 'GitHub'],
              [Linkedin, P.socials.linkedin, 'LinkedIn'],
              [Mail, `mailto:${P.socials.email}`, 'Email'],
            ].map(([Icon, href, label], i) => {
              const I = Icon as typeof Github;
              return (
                <a
                  key={i}
                  href={href as string}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={label as string}
                  className="p-3 rounded-xl bg-white border border-slate-100 shadow-card text-brand-navy hover:text-brand-blue hover:scale-105 hover:shadow-lift transition-all duration-200"
                >
                  <I className="w-5 h-5" />
                </a>
              );
            })}
          </div>
        </motion.div>

        {/* Right Column: 3D Robot + Profile */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.15, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="lg:col-span-6 relative flex justify-center items-center"
        >
          {/* Background glow */}
          <div className="absolute w-[80%] aspect-square rounded-full bg-gradient-to-br from-brand-sky/20 via-brand-blue/10 to-brand-orange/5 blur-3xl top-4 pointer-events-none" />

          {/* Profile photo positioned top-right */}
          <div className="absolute top-0 right-4 sm:right-10 z-20">
            <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden shadow-lift ring-4 ring-white">
              <img
                src="/profile.jpg"
                alt={P.name}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* 3D Robot */}
          <div className="w-full h-[400px] sm:h-[480px] lg:h-[540px] relative z-10">
            <Robot3D
              clip={robotClip}
              loop={robotClip === 'Idle_15'}
              className="w-full h-full"
              cam={[0, 1.0, 3.8]}
              fov={36}
            />
          </div>

          {/* Speech bubble */}
          <div className="absolute bottom-8 left-4 sm:left-8 z-20 font-hand text-lg sm:text-xl text-brand-blue bg-white/95 backdrop-blur-sm px-4 py-2.5 rounded-2xl shadow-card border border-brand-sky/20 select-none">
            Hello! 👋
            <br />
            Let's build
            <br />
            something amazing! 🚀
          </div>
        </motion.div>
      </div>
    </section>
  );
}
