import { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Splash } from './components/Splash';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ScrollCompanion } from './components/ScrollCompanion';
import { Hero } from './sections/Hero';
import { About } from './sections/About';
import { Skills } from './sections/Skills';
import { Projects } from './sections/Projects';
import { RobotLab } from './sections/RobotLab';
import { Contact } from './sections/Contact';

const SECTION_IDS = ['home', 'about', 'skills', 'projects', 'lab', 'contact'] as const;

export default function App() {
  const [loading, setLoading] = useState(true);

  return (
    <>
      <AnimatePresence mode="wait">
        {loading && <Splash onDone={() => setLoading(false)} />}
      </AnimatePresence>
      {!loading && (
        <>
          <Navbar />
          <ScrollCompanion sectionIds={[...SECTION_IDS]} />
          <main>
            <Hero />
            <About />
            <Skills />
            <Projects />
            <RobotLab />
            <Contact />
          </main>
          <Footer />
        </>
      )}
    </>
  );
}
