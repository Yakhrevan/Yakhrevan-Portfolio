import { Project, SkillCategory, ExperienceItem, LabExperiment } from '../types/portfolio';

export const PERSONAL_INFO = {
  name: "Yakhrevan",
  title: "Mechatronics Engineer",
  tagline: "A small engineer for a bigger tomorrow.",
  bio: "I'm Yakhrevan, a Mechatronics Engineer passionate about robotics, embedded systems, AI and autonomous machines. I enjoy turning ideas into real-world solutions, from concept design to hardware integration and intelligent control.",
  location: "India",
  status: "Always Learning, Always Building",
  socials: {
    github: "https://github.com/Yakhrevan",
    linkedin: "https://linkedin.com/in/yakhrevan",
    email: "yakhrevan@gmail.com"
  }
};

export const PROJECTS_DATA: Project[] = [
  {
    id: "pickbot",
    title: "Pickbot",
    subtitle: "Mecanum wheel robot with embedded control and automation",
    category: "Robotics",
    description: "A versatile mecanum wheel robot featuring omnidirectional movement and automated tasks, demonstrating advanced embedded control.",
    longDescription: "Pickbot is a custom-designed mecanum wheel robot platform focusing on precise omnidirectional movement. It integrates ESP32 microcontrollers with motor drivers to enable complex navigation routines and wireless control. (Placeholder details - will be updated based on actual project specs).",
    tags: ["Robotics", "ESP32", "Motor Control", "C++"],
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Custom chassis design for mecanum wheels",
      "Wireless control using ESP32",
      "Omnidirectional movement algorithms",
      "Open-source hardware approach"
    ],
    specs: [
      { label: "Controller", value: "ESP32" },
      { label: "Drive", value: "Mecanum" },
      { label: "Role", value: "Hardware & Software" },
      { label: "Status", value: "Completed" }
    ],
    robotMood: "Excited",
    robotComment: "Look at those mecanum wheels go! Pickbot can strafe in any direction!",
    githubUrl: "#",
    featured: true
  },
  {
    id: "morphobot",
    title: "Morphobot",
    subtitle: "Hybrid rover/drone with vision and autonomous operation",
    category: "Robotics",
    description: "An innovative hybrid robot capable of both ground roving and aerial operation, utilizing computer vision for navigation.",
    longDescription: "Morphobot explores the intersection of ground and aerial robotics. Equipped with ROS 2 and computer vision capabilities, it can autonomously navigate different terrains and identify targets. (Placeholder details - will be updated based on actual project specs).",
    tags: ["ROS 2", "Computer Vision", "AI", "Python"],
    image: "https://images.unsplash.com/photo-1527443154391-507e9dc6cbe5?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Hybrid locomotion system",
      "ROS 2 based autonomous navigation",
      "Computer vision for object tracking",
      "Adaptive control algorithms"
    ],
    specs: [
      { label: "Framework", value: "ROS 2" },
      { label: "Perception", value: "Vision-based" },
      { label: "Type", value: "Hybrid Rover/Drone" },
      { label: "Status", value: "Development" }
    ],
    robotMood: "Thinking",
    robotComment: "A robot that can roll AND fly? That's some next-level engineering right there!",
    githubUrl: "#",
    featured: true
  },
  {
    id: "obstacle-avoidance-bot",
    title: "Obstacle Avoidance Bot",
    subtitle: "Ultrasonic based autonomous navigation prototype",
    category: "Embedded",
    description: "A fundamental robotics project demonstrating autonomous navigation and environment sensing using ultrasonic sensors.",
    longDescription: "This autonomous robot uses ultrasonic sensors to detect obstacles in its path and alter its course in real-time. It serves as a practical exploration of basic sensing, decision making, and motor control in embedded systems. (Placeholder details - will be updated based on actual project specs).",
    tags: ["Arduino", "Sensors", "Embedded", "C++"],
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Real-time obstacle detection",
      "Reactive navigation algorithms",
      "Low-latency sensor polling",
      "Efficient power management"
    ],
    specs: [
      { label: "Sensors", value: "Ultrasonic" },
      { label: "Controller", value: "Arduino" },
      { label: "Locomotion", value: "Differential Drive" },
      { label: "Focus", value: "Reactive Control" }
    ],
    robotMood: "Focused",
    robotComment: "Scanning... Scanning... Obstacle detected! Rerouting trajectory immediately!",
    githubUrl: "#",
    featured: true
  }
];

export const SKILLS_DATA: SkillCategory[] = [
  {
    title: "Programming",
    iconName: "Code",
    skills: [
      { name: "Python", level: 90, tagline: "Scripts, AI & Backend" },
      { name: "C++", level: 85, tagline: "High-performance & ROS" },
      { name: "Java", level: 80, tagline: "Object-oriented systems" },
      { name: "Embedded C", level: 85, tagline: "Microcontroller logic" }
    ]
  },
  {
    title: "Robotics & AI",
    iconName: "Cpu",
    skills: [
      { name: "ROS 2", level: 85, tagline: "Robot Operating System" },
      { name: "OpenCV", level: 80, tagline: "Computer Vision" },
      { name: "YOLO", level: 75, tagline: "Object Detection" },
      { name: "SLAM", level: 70, tagline: "Mapping & Navigation" }
    ]
  },
  {
    title: "Embedded Systems",
    iconName: "Activity",
    skills: [
      { name: "ESP32", level: 90, tagline: "IoT & Wireless" },
      { name: "STM32", level: 80, tagline: "Advanced ARM Control" },
      { name: "Arduino", level: 95, tagline: "Prototyping" },
      { name: "Raspberry Pi", level: 85, tagline: "SBC Computing" }
    ]
  },
  {
    title: "Design & CAD",
    iconName: "PenTool",
    skills: [
      { name: "SolidWorks", level: 85, tagline: "3D Mechanical Design" },
      { name: "AutoCAD", level: 80, tagline: "2D Drafting" },
      { name: "Blender", level: 70, tagline: "3D Modeling" }
    ]
  },
  {
    title: "Web & Apps",
    iconName: "Globe",
    skills: [
      { name: "React", level: 80, tagline: "Frontend UI" },
      { name: "Node.js", level: 75, tagline: "Backend Services" },
      { name: "MongoDB", level: 70, tagline: "NoSQL Database" }
    ]
  },
  {
    title: "Tools & Others",
    iconName: "Wrench",
    skills: [
      { name: "Git", level: 90, tagline: "Version Control" },
      { name: "Linux", level: 85, tagline: "OS & Server Admin" },
      { name: "Docker", level: 75, tagline: "Containerization" }
    ]
  }
];

export const EXPERIENCE_DATA: ExperienceItem[] = [
  {
    id: "exp-2024-intern",
    role: "Internship",
    company: "Emote Electric",
    period: "2024",
    location: "India",
    description: "Worked on embedded systems and EV technology, gaining practical experience in hardware-software integration.",
    achievements: [
      "Collaborated with engineering team on EV sub-systems",
      "Developed embedded firmware for monitoring modules",
      "Participated in testing and validation of electrical components"
    ],
    technologies: ["Embedded C", "Microcontrollers", "EV Systems", "Hardware Testing"]
  },
  {
    id: "exp-2024-projects",
    role: "Project Development",
    company: "Personal Projects",
    period: "2024",
    location: "India",
    description: "Designed and built robotic prototypes focusing on autonomous navigation and hybrid locomotion.",
    achievements: [
      "Developed Pickbot, a mecanum wheel robot with omnidirectional control",
      "Engineered Morphobot, exploring hybrid ground/aerial capabilities",
      "Implemented wireless telemetry and control using ESP32"
    ],
    technologies: ["ESP32", "ROS 2", "C++", "Python", "Motor Control"]
  },
  {
    id: "exp-2023-skills",
    role: "Skill Expansion",
    company: "Self-Directed Learning",
    period: "2023",
    location: "India",
    description: "Deepened knowledge in autonomous systems, focusing on modern robotics frameworks and computer vision.",
    achievements: [
      "Mastered ROS 2 core concepts and node communication",
      "Implemented computer vision pipelines using OpenCV and YOLO",
      "Explored IoT architectures for connected robotics"
    ],
    technologies: ["ROS 2", "OpenCV", "AI/ML", "IoT", "Python"]
  },
  {
    id: "exp-2022-academic",
    role: "Academic Foundation",
    company: "B.E. Mechatronics",
    period: "2022",
    location: "India",
    description: "Started my formal journey into robotics and automation, building a strong foundation in mechanical, electrical, and software engineering.",
    achievements: [
      "Studied control systems, kinematics, and embedded design",
      "Participated in foundational robotics workshops and competitions",
      "Built initial autonomous line-following and obstacle-avoiding robots"
    ],
    technologies: ["Arduino", "C/C++", "CAD", "Electronics"]
  }
];

export const LAB_EXPERIMENTS: LabExperiment[] = [
  {
    id: "exp-lab-1",
    title: "Inverse Kinematics Visualizer",
    type: "Kinematics",
    description: "Interactive 3D joint coordinate simulation for multi-link manipulator arms.",
    status: "Active",
    interactiveAction: "Simulate Joints"
  },
  {
    id: "exp-lab-2",
    title: "LiDAR Point Cloud Mesh Generator",
    type: "Vision",
    description: "Simulated 2D depth projection into 3D voxel grids using custom Three.js shader materials.",
    status: "Stable",
    interactiveAction: "Run Point Cloud"
  },
  {
    id: "exp-lab-3",
    title: "PID Control Loop Tuner",
    type: "Simulation",
    description: "Interactive visualization of Proportional-Integral-Derivative tuning for stabilization.",
    status: "Experimental",
    interactiveAction: "Tune Parameters"
  }
];

export const projects = PROJECTS_DATA;
export const skillCategories = SKILLS_DATA;
export const experiences = EXPERIENCE_DATA;
export const labExperiments = LAB_EXPERIMENTS;
